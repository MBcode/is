import spacy

class SRToken(spacy.tokens.Token):
