# with nlp.select_pipes(enable="parser"):
#     doc = nlp("I will only be parsed")